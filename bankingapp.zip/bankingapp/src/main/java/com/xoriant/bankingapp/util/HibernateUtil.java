package com.xoriant.bankingapp.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
	private static SessionFactory Factory=null;
	
	private HibernateUtil(){
		
	}
	
  public static SessionFactory getSessionFactory() {
	  if(Factory==null) {
		  Factory= new Configuration().configure().buildSessionFactory();
	  }
	  return Factory;
  }

  public static void main(String[] args) {
	SessionFactory f1=getSessionFactory();
	
}
}
