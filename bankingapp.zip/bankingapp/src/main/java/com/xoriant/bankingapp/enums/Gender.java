package com.xoriant.bankingapp.enums;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public enum Gender {
	MALE,
	FEMALE;

	public static List<String> getGenderValues() {
		
		return Stream.of(Gender.values())
                .map(Gender::name)
                .collect(Collectors.toList());
	}
	
	public static void main(String[] args) {
		
		System.out.println(getGenderValues());
	}
}
