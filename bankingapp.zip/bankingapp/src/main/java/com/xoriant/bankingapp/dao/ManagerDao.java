package com.xoriant.bankingapp.dao;

import java.util.List;

import com.xoriant.bankingapp.dto.AccountDto;
import com.xoriant.bankingapp.dto.FundTransferDto;
import com.xoriant.bankingapp.dto.NewCustomerDto;
import com.xoriant.bankingapp.dto.customerInfoDto;
import com.xoriant.bankingapp.model.Account;
import com.xoriant.bankingapp.model.Customer;
import com.xoriant.bankingapp.model.PersonalInfo;

public interface ManagerDao {
	
 

	void saveCustomer(PersonalInfo personalInfo);
	
	void saveAccount(Account account);
	
	List<customerInfoDto> getallcustomers();

	void addAccount(Account accountobj);

	List<Account> getBalanceByAccountNumber(long accountNumber);

	List<Account> deposit(long accountNumber, double amount,Account account);

	void saveupdatedbalance(double updatedbalance, long accountNumber);

	List<Account> withdraw(long accountNumber, double amount, Account account);


	List<FundTransferDto> fundtransfer(FundTransferDto fundtransferdto);

	void deleteAccount(long accountNumber);

	List<Account> getAccountDetails(long accountNumber, Account account);

	void updateAccount(double currentbalance, double minimumBalance,long accountNumber);
	
	
	
	
	//public List<PersonalInfo> findBypersonId(Integer personId);
	

}
