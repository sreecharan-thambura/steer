package com.xoriant.bankingapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xoriant.bankingapp.dao.ManagerDao;
import com.xoriant.bankingapp.dto.AccountDto;
import com.xoriant.bankingapp.dto.FundTransferDto;
import com.xoriant.bankingapp.dto.NewCustomerDto;
import com.xoriant.bankingapp.dto.customerInfoDto;
import com.xoriant.bankingapp.model.Account;
import com.xoriant.bankingapp.model.Customer;
import com.xoriant.bankingapp.model.PersonalInfo;

@Service
public class ManagerServiceImpl implements ManagerService{
	
	@Autowired
	ManagerDao managerdao;

	/*
	 * @Override public void saveCustomer(PersonalInfo personalInfo) {
	 * managerdao.saveCustomer(personalInfo); }
	 */
	@Override
	public void saveCustomer(PersonalInfo personalInfo) {
		managerdao.saveCustomer(personalInfo);
		}

	@Override
	public void saveAccount(Account account) {
		 managerdao.saveAccount(account);
		
	}

	@Override
	public List<customerInfoDto> getallcustomers() {

	List<customerInfoDto>clist =	managerdao.getallcustomers();
		return clist;
	}

	@Override
	public void addAccount(Account accountobj) {
		
		managerdao.addAccount(accountobj);
	}

	@Override
	public List<Account> getBalanceByAccountNumber(long accountNumber) {
		return managerdao.getBalanceByAccountNumber(accountNumber);
		
	}


	@Override
	public List<Account> deposit(long accountNumber, double amount,Account account) {
		return managerdao.deposit(accountNumber,amount,account);
	}

	@Override
	public void saveupdatedbalance(double updatedbalance,long accountNumber) {
		System.out.println("service called");
		managerdao.saveupdatedbalance(updatedbalance,accountNumber);
	}

	@Override
	public List<Account> withdraw(long accountNumber, double amount, Account account) {
		return managerdao.withdraw(accountNumber,amount,account);
	}

	@Override
	public List<FundTransferDto> fundtransfer(FundTransferDto fundtransferdto) {
		return managerdao.fundtransfer(fundtransferdto);
	}

	@Override
	public void deleteAccount(long accountNumber) {
		managerdao.deleteAccount(accountNumber);
	}

	@Override
	public List<Account> getAccountDetails(long accountNumber, Account account) {
		return managerdao.getAccountDetails(accountNumber,account);
		 
	}

	@Override
	public void updateAccount(double currentbalance, double minimumBalance,long accountNumber) {
		managerdao.updateAccount(currentbalance,minimumBalance,accountNumber);
	}



}
