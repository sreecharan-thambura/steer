package com.xoriant.bankingapp.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.xoriant.bankingapp.enums.AccountType;
import com.xoriant.bankingapp.model.Customer;


public class AccountDto {
	
	private Customer customerId;
	private long accountNumber;
	private double accountBalance;
	private double minimumBalance;
	private Date dateOfOpening;
	private Date dataOfClosure;
	private String description;
	//private List<AccountType>accountTypes;
	//private String accountType;
	
	public long getAccountNumber() {
		return accountNumber;
	}
	public Customer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Customer customerId) {
		this.customerId = customerId;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public double getMinimumBalance() {
		return minimumBalance;
	}
	public void setMinimumBalance(double minimumBalance) {
		this.minimumBalance = minimumBalance;
	}
	public Date getDateOfOpening() {
		return dateOfOpening;
	}
	public void setDateOfOpening(Date dateOfOpening) {
		this.dateOfOpening = dateOfOpening;
	}
	public Date getDataOfClosure() {
		return dataOfClosure;
	}
	public void setDataOfClosure(Date dataOfClosure) {
		this.dataOfClosure = dataOfClosure;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "AccountDto [customerId=" + customerId + ", accountNumber=" + accountNumber + ", accountBalance="
				+ accountBalance + ", minimumBalance=" + minimumBalance + ", dateOfOpening=" + dateOfOpening
				+ ", dataOfClosure=" + dataOfClosure + ", description=" + description + "]";
	}
	
	

}
