package com.xoriant.bankingapp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.xoriant.bankingapp.dto.customerInfoDto;
import com.xoriant.bankingapp.model.Customer;
import com.xoriant.bankingapp.model.User;

@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	private EntityManagerFactory entityManagerFactory;
	//EntityManager entityManger = entityManagerFactory.createEntityManager();
	//EntityTransaction transaction = entityManger.getTransaction();

	@Override
	public void insertUser(User user) {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		entityManger.persist(user);
		transaction.commit();
		entityManger.close();
	}

	/*
	 * @Override public User authenticateUser(User user) {
	 * 
	 * EntityManager entityManger = entityManagerFactory.createEntityManager();
	 * EntityTransaction transaction = entityManger.getTransaction();
	 * transaction.begin(); Query query=entityManger.
	 * createQuery("from User u where u.userName =:username and password=:password",
	 * User.class); query.setParameter("username", user.getUserName());
	 * query.setParameter("password", user.getPassword()); User
	 * userResult=(User)query.getSingleResult(); transaction.commit();
	 * entityManger.close(); return userResult; }
	 */

	@Override
	public User authenticateUser(User user) {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
		Query query=entityManger.createQuery("from User u where u.userName =:username and password=:password,User.class");
		query.setParameter("username", user.getUserName());
		query.setParameter("password", user.getPassword());
		User u = (User) query.getSingleResult();
		return u;
	}

	@Override
	public void changepassword(String userName, String password) {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		Query query = entityManger. createQuery("update User u set u.password=:pw where userName=:un");
		query.setParameter("pw", password);
		query.setParameter("un",userName);
		query.executeUpdate();
		transaction.commit();
		entityManger.close();		
		//return null;
	}

	@Override
	public List<User> getUsers(User user) {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		Query query = entityManger.createQuery("from User", User.class);
		List<User> userlist = (List<User>)query.getResultList();
		transaction.commit();
		entityManger.close();
		return userlist;
	}

	

}
