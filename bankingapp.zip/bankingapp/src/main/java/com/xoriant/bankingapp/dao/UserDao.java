package com.xoriant.bankingapp.dao;

import java.util.List;

import com.xoriant.bankingapp.model.PersonalInfo;
import com.xoriant.bankingapp.model.User;

public interface UserDao {
	
	void insertUser(User user);
	//User authenticateUser(String userName, String password);
	User authenticateUser(User user);
	void changepassword(String userName, String password);
	List<User> getUsers(User user);
	
	

}
