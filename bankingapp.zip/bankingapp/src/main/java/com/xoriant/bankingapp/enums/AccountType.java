package com.xoriant.bankingapp.enums;

public enum AccountType {
	
	SAVING, CURRENT;

}
