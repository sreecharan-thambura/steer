package com.xoriant.bankingapp.enums;

public enum Frequency {
	
	WEEKLY,
	MONTHLY,
	QUARTERLY,
	SEMIANNUAL,
	ANNUAL;
	

}
