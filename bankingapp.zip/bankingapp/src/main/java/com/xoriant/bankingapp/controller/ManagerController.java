package com.xoriant.bankingapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.xoriant.bankingapp.dto.AccountDto;
import com.xoriant.bankingapp.dto.FundTransferDto;
import com.xoriant.bankingapp.dto.NewCustomerDto;
import com.xoriant.bankingapp.dto.customerInfoDto;
import com.xoriant.bankingapp.enums.Gender;
import com.xoriant.bankingapp.model.Account;
import com.xoriant.bankingapp.model.Customer;
import com.xoriant.bankingapp.model.Manager;
import com.xoriant.bankingapp.model.PersonalInfo;
import com.xoriant.bankingapp.service.ManagerService;


@Controller
public class ManagerController {

	@Autowired
	ManagerService managerservice;

	@ModelAttribute("personalInfo")
	public PersonalInfo ps() {
		return new PersonalInfo();
	}

	
	
	/*
	 * @ModelAttribute("Customer") public Customer customer() { return new
	 * Customer(); }
	 */
	@GetMapping("/NewCustomer")
	public String addCustomer() {
		return "NewCustomer";
	}

	
	  @PostMapping("/NewCustomer") 
	  public String saveCustomer(@ModelAttribute PersonalInfo personalInfo) {
		  managerservice.saveCustomer(personalInfo);
	  return "Manager"; 
	  }
	 
	@ModelAttribute("customerInfoDto")
	public customerInfoDto customer() {
		List<String> genders= Gender.getGenderValues();
		customerInfoDto customerInfoDto = new customerInfoDto();
		customerInfoDto.setGender(genders);
		return customerInfoDto;
	}

	
	/*
	 * @PostMapping("/NewCustomer") public String saveCustomer(@ModelAttribute
	 * Customer customer) { Manager manager = new Manager(); manager.setPersonId(2);
	 * customer.setManager(manager); managerservice.saveCustomer(customer); return
	 * "Manager"; }
	 */
	@ModelAttribute("accountobj")
	public Account account() {
		return new Account();
	}
	 

	@GetMapping("/NewAccount")
	public String addAccount() {
	
	
		return "NewAccount";
	}

	/*
	 * @PostMapping("/NewAccount") public String createAccount(@ModelAttribute
	 * Account accountobj) { managerservice.saveAccount(accountobj); return
	 * "Manager"; }
	 */
	 
	@GetMapping("/getAllCustomer")
	public String getAllCustomer(Model model) {
		List<customerInfoDto> list = managerservice.getallcustomers();
		model.addAttribute("list", list);
		return "customerList";
	}
	
	/*
	 * @GetMapping("/addAccount") public String addAccount(Model model) {
	 * managerservice. model.addAttribute("list", list); return "customerList"; }
	 */
	
	
	@PostMapping("/NewAccount")
	public String addAccount(@ModelAttribute Account accountobj)
	{
		managerservice.addAccount(accountobj);
		return "Manager";
	}

	@ModelAttribute("AccountDto")
	public AccountDto acc() {
		return new AccountDto();
	}

	@GetMapping("/BalanceEnquiry")
	public String getAccountnumber() {
	
		return "BalanceEnquiry";
	}
	
	@PostMapping("/BalanceEnquiry")
	public String balanceEnquiry(@RequestParam long accountNumber,Model model)
	{
		
		List<Account> list = managerservice.getBalanceByAccountNumber(accountNumber);
		model.addAttribute("list", list);
		
		return "balance";
	}
	
	@GetMapping("/Deposit")
	public String deposit() {
	
		return "Deposit";
	}
	
	@PostMapping("/Deposit")
	public String depositMoney(@RequestParam long accountNumber,@RequestParam double amount,Account account)
	{
		List<Account> list = managerservice.deposit(accountNumber,amount,account);
		for(Account l:list) {
			double currentbalance = l.getAccountBalance();
			double updatedbalance=currentbalance+amount;
			System.out.println(updatedbalance);
			managerservice.saveupdatedbalance(updatedbalance,accountNumber);
		}
		
		return "Manager";
	}
	
	
	@GetMapping("/Withdraw")
	public String withdraw() {
	
		return "Withdraw";
	}
	
	@PostMapping("/Withdraw")
	public String withdrawmoney(@RequestParam long accountNumber,@RequestParam double amount,Account account) {
		List<Account> list = managerservice.withdraw(accountNumber,amount,account);
		for(Account l:list) {
			double currentbalance = l.getAccountBalance();
			double updatedbalance=currentbalance-amount;
			System.out.println(updatedbalance);
			managerservice.saveupdatedbalance(updatedbalance,accountNumber);
		}
		
		return "Manager";
		
	}
	
	@ModelAttribute("fundtransferdto")
	public FundTransferDto fund() {
		FundTransferDto fundtransferdto=new FundTransferDto();
		return fundtransferdto;
	}

	
	@GetMapping("/fundTransfer")
	public String fundTransfer() {
	
		return "FundTransfer";
	}
	
	@PostMapping("/fundTransfer")
	public String fundTransferfromAccount(@ModelAttribute FundTransferDto fundtransferdto) {
		List<FundTransferDto> list = managerservice.fundtransfer(fundtransferdto);
		System.out.println(list);
		return "Manager";
		
	}
	
	@GetMapping("/deleteAccount")
	public String deleteAcc() {
		return "DeleteAccount";
	}
	
	@PostMapping("/deleteAccount")
	public String deleteAccount(@RequestParam long accountNumber) {
		managerservice.deleteAccount(accountNumber);
		return "Manager";
		
	}
	
	@GetMapping("/editAccount")
	public String editAccount() {
		return "EditAccount";
	}
	
	@PostMapping("/editAccount")
	public String editAcc(@RequestParam long accountNumber,Account account,Model model) {
		List<Account> list = managerservice.getAccountDetails(accountNumber,account);
		model.addAttribute("list", list);	
		for(Account l:list) {
			double currentbalance = l.getAccountBalance();
			double minimumbalance=l.getMinimumBalance();
			System.out.println(minimumbalance);
			//managerservice.updateAccount(accountBalance,minimumBalance,accountNumber);
			
		
		}
		
		return "EditAccountForm";
		
	}
	
	/*
	 * @PostMapping("/UpdateAccount") public String updateAccount(long
	 * accountBalance,long minimumBalance,long accountNumber) {
	 * System.out.println("in update account method");
	 * managerservice.updateAccount(accountBalance,minimumBalance,accountNumber);
	 * return "Manager";
	 * 
	 * }
	 */
	
}
