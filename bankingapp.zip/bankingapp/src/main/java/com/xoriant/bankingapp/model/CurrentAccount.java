package com.xoriant.bankingapp.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.PrimaryKeyJoinColumn;

import com.xoriant.bankingapp.enums.AccountStatus;
import com.xoriant.bankingapp.enums.AccountType;
import com.xoriant.bankingapp.enums.Frequency;
@Entity
public class CurrentAccount extends Account {
	private double recurringAmount;
	@Enumerated(EnumType.STRING)
	private Frequency frequency;
	private int termInMonths;
	public CurrentAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CurrentAccount(long accountNumber, double accountBalance, double minimumBalance, Date dateOfOpening,
			Date dataOfClosure, String description, AccountStatus accountStatus, AccountType accountType,
			List<Transaction> transactions, Customer customer) {
		super(accountNumber, accountBalance, minimumBalance, dateOfOpening, dataOfClosure, description, accountStatus,
				accountType, transactions, customer);
		// TODO Auto-generated constructor stub
	}
	public CurrentAccount(long accountNumber, double accountBalance, double minimumBalance, Date dateOfOpening,
			Date dataOfClosure, String description, AccountStatus accountStatus, AccountType accountType,
			List<Transaction> transactions, Customer customer, double recurringAmount, Frequency frequency,
			int termInMonths) {
		super(accountNumber, accountBalance, minimumBalance, dateOfOpening, dataOfClosure, description, accountStatus,
				accountType, transactions, customer);
		this.recurringAmount = recurringAmount;
		this.frequency = frequency;
		this.termInMonths = termInMonths;
	}
	public double getRecurringAmount() {
		return recurringAmount;
	}
	public void setRecurringAmount(double recurringAmount) {
		this.recurringAmount = recurringAmount;
	}
	public Frequency getFrequency() {
		return frequency;
	}
	public void setFrequency(Frequency frequency) {
		this.frequency = frequency;
	}
	public int getTermInMonths() {
		return termInMonths;
	}
	public void setTermInMonths(int termInMonths) {
		this.termInMonths = termInMonths;
	}
	@Override
	public String toString() {
		return "CurrentAccount [recurringAmount=" + recurringAmount + ", frequency=" + frequency + ", termInMonths="
				+ termInMonths + "]";
	}
	
	
}
