package com.xoriant.bankingapp.service;

import java.util.List;

import com.xoriant.bankingapp.model.Account;

public interface CustomerService {
	public Account balanceEnquiry();

	public List<Account> getBalanceByAccountNumber(long accountNumber);

}
