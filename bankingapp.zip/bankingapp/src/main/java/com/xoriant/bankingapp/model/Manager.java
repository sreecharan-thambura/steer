package com.xoriant.bankingapp.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
@Entity
public class Manager extends PersonalInfo {
		
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "branchId")
	private Branch branch;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "manager")
	private List<Customer> customer;

	public Manager() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public List<Customer> getCustomer() {
		return customer;
	}

	public void setCustomer(List<Customer> customer) {
		this.customer = customer;
	}

	public Manager(Branch branch, List<Customer> customer) {
		super();
		this.branch = branch;
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Manager [branch=" + branch + ", customer=" + customer + "]";
	}
	
	

}
