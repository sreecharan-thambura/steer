package com.xoriant.bankingapp.enums;

public enum AccountStatus {
	
	ACTIVE,   INACTIVE;

}
