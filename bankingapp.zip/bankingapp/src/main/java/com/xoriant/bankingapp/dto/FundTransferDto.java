package com.xoriant.bankingapp.dto;

import java.util.Date;

import com.xoriant.bankingapp.model.Account;
import com.xoriant.bankingapp.model.Customer;
import com.xoriant.bankingapp.model.Transaction;

public class FundTransferDto {
	
	private Account fromAccount;
	private Account toAccount;
	private double amount;
	private Transaction transaction;
	public Account getFromAccount() {
		return fromAccount;
	}
	public void setFromAccount(Account fromAccount) {
		this.fromAccount = fromAccount;
	}
	public Account getToAccount() {
		return toAccount;
	}
	public void setToAccount(Account toAccount) {
		this.toAccount = toAccount;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Transaction getTransaction() {
		return transaction;
	}
	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}
	@Override
	public String toString() {
		return "FundTransferDto [fromAccount=" + fromAccount + ", toAccount=" + toAccount + ", amount=" + amount
				+ ", transaction=" + transaction + "]";
	}
	
	

}
