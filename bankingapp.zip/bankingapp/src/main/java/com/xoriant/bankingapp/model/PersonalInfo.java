package com.xoriant.bankingapp.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;

import org.hibernate.annotations.NamedNativeQueries;

import com.xoriant.bankingapp.enums.Gender;





@Entity
@Inheritance(strategy = InheritanceType.JOINED)

public class PersonalInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	protected int personId;
	protected String personName;
	protected String emailId;
	protected long mobileNumber;

	@Enumerated(EnumType.STRING)
	protected Gender gender;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "user_Id")
	protected User user;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "address_Id")
	protected Address address;

	public PersonalInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PersonalInfo(int personId, String personName, String emailId, long mobileNumber, Gender gender, User user,
			Address address) {
		super();
		this.personId = personId;
		this.personName = personName;
		this.emailId = emailId;
		this.mobileNumber = mobileNumber;
		this.gender = gender;
		this.user = user;
		this.address = address;
	}

	public int getPersonId() {
		return personId;
	}

	public void setPersonId(int personId) {
		this.personId = personId;
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	
	

}
