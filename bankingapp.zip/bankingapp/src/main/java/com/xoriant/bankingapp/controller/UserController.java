package com.xoriant.bankingapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.xoriant.bankingapp.dao.UserDao;
import com.xoriant.bankingapp.enums.Role;
import com.xoriant.bankingapp.model.User;
import com.xoriant.bankingapp.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@ModelAttribute("userObj")
    public User user() {
		return new User();
	}
	
	@GetMapping("/user")
	public String addUser() {
		return "addUser";
	}
	
	 @PostMapping("/logincheck")
	    public String validateUser(User user) {
	    	 User user2 = userService.authenticateUser(user);
	    	 System.out.println(user2.getUserName());
	    	// if(user.getRole().equals(Role.CUSTOMER)&&{(user.getUserName().equals("")))}
	    	 
	    	
			return "check";
//			return null;
	 }	
	
	/*
	 * @PostMapping("/addUser") public String addUser(@ModelAttribute User userObj)
	 * {
	 * 
	 * userService.insertUser(userObj); if(userObj.getRole().equals(Role.CUSTOMER))
	 * return "login"; }
	 */
	
	
}
