package com.xoriant.bankingapp.dao;

import java.util.List;

import com.xoriant.bankingapp.model.Account;

public interface CustomerDao {
	public Account balanceEnquiry();

	public List<Account> getBalanceByAccountNumber(long accountNumber);
	 


}
