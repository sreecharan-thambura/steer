package com.xoriant.bankingapp.service;

import java.util.List;

import com.xoriant.bankingapp.dto.AccountDto;
import com.xoriant.bankingapp.dto.FundTransferDto;
import com.xoriant.bankingapp.dto.NewCustomerDto;
import com.xoriant.bankingapp.dto.customerInfoDto;
import com.xoriant.bankingapp.model.Account;
import com.xoriant.bankingapp.model.Customer;
import com.xoriant.bankingapp.model.PersonalInfo;

public interface ManagerService {

	 void saveCustomer(PersonalInfo personalInfo);
	 
	 public void saveAccount(Account account);
	 
	 List<customerInfoDto> getallcustomers();
	 
	 public void addAccount(Account accountobj);

	 List<Account> getBalanceByAccountNumber(long accountNumber);

	//void deposit(int accountNumber, double amount);

	 List<Account> deposit(long accountNumber, double amount, Account account);

	void saveupdatedbalance(double updatedbalance,long accountNumber);

	List<Account> withdraw(long accountNumber, double amount, Account account);

	List<FundTransferDto> fundtransfer(FundTransferDto fundtransferdto);

	void deleteAccount(long accountNumber);

	List<Account> getAccountDetails(long accountNumber, Account account);

	void updateAccount(double accountBalance, double minimumBalance,long accountNumber);

}
