package com.xoriant.bankingapp.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.xoriant.bankingapp.dto.AccountDto;
import com.xoriant.bankingapp.dto.FundTransferDto;
import com.xoriant.bankingapp.dto.NewCustomerDto;
import com.xoriant.bankingapp.dto.customerInfoDto;
import com.xoriant.bankingapp.model.Account;
import com.xoriant.bankingapp.model.Customer;
import com.xoriant.bankingapp.model.Manager;
import com.xoriant.bankingapp.model.PersonalInfo;

@Repository
public class ManagerDaoImpl implements ManagerDao {

	@Autowired
	private EntityManagerFactory entityManagerFactory;

	/*
	 * @Override public void saveCustomer(PersonalInfo personalInfo) { EntityManager
	 * entityManger = entityManagerFactory.createEntityManager(); EntityTransaction
	 * transaction = entityManger.getTransaction(); transaction.begin();
	 * entityManger.persist(personalInfo); transaction.commit();
	 * entityManger.close(); }
	 */

	@Override
	public void saveCustomer(PersonalInfo personalInfo) {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		entityManger.persist(personalInfo);
		transaction.commit();
		entityManger.close();
	}

	@Override
	public void saveAccount(Account account) {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
//		Customer customer = new Customer();
//		int personId = account.getCustomer().getPersonId();
//		customer.setPersonId(personId);

	//	Account account2 = new Account();
	//	account2.setCustomer(customer);

		entityManger.persist(account);
		transaction.commit();
		entityManger.close();

	}

	@Override
	public List<customerInfoDto> getallcustomers() {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		Query query = entityManger.createQuery("from Customer", Customer.class);
		List<customerInfoDto> custinfo = (List<customerInfoDto>)query.getResultList();
		// Query<Employee> empq =session.createNamedQuery("all_emp");

		//List<PersonalInfo> list1 = query.getResultList();
		
	
		System.out.println(custinfo);

		/*
		 * for (PersonalInfo info : list1) {
		 * personalInfo.setPersonId(info.getPersonId());
		 * personalInfo.setPersonName(info.getPersonName()); } //
		 * list1.add(personalInfo);
		 * 
		 */
		transaction.commit();
		entityManger.close();
		return custinfo;
	}

	@Override
	public void addAccount(Account accountobj) {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		
		/*
		 * Account ac=new Account();
		 * ac.setAccountBalance(accountdto.getAccountBalance());
		 * ac.setAccountNumber(accountdto.getAccountNumber());
		 * ac.setCustomer(accountdto.getCustomerId());
		 * ac.setDateOfOpening(accountdto.getDateOfOpening());
		 * ac.setDescription(accountdto.getDescription());
		 * ac.setMinimumBalance(accountdto.getMinimumBalance());
		 */
		 
		
		entityManger.persist(accountobj);
		transaction.commit();
		entityManger.close();

		
	}

	@Override
	public List<Account> getBalanceByAccountNumber(long accountNumber) {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();	
		Query query = entityManger.createQuery("SELECT a FROM Account a WHERE a.accountNumber LIKE :ac");
		query.setParameter("ac", accountNumber);
		List list = (List<Account>)query.getResultList();
		System.out.println(list);
		return list;
	}

	@Override
	public List<Account> deposit(long accountNumber, double amount,Account account) {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();	
		Query query = entityManger.createQuery("SELECT a FROM Account a WHERE a.accountNumber LIKE :ac");
		query.setParameter("ac", accountNumber);
		List list = (List<Account>)query.getResultList();
		System.out.println(list);
		return list;
		
	}


	@Override
	public void saveupdatedbalance(double updatedbalance,long accountNumber) {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
	    transaction.begin();
		Query query = entityManger. createQuery("update Account a set a.accountBalance=:ab where accountNumber=:an");
		query.setParameter("ab", updatedbalance);
		query.setParameter("an",accountNumber);
		query.executeUpdate();
		transaction.commit();
		entityManger.close();		
	}

	@Override
	public List<Account> withdraw(long accountNumber, double amount, Account account) {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();	
		Query query = entityManger.createQuery("SELECT a FROM Account a WHERE a.accountNumber LIKE :ac");
		query.setParameter("ac", accountNumber);
		List list = (List<Account>)query.getResultList();
		System.out.println(list);
		return list;
	}

	@Override
	public List<FundTransferDto> fundtransfer(FundTransferDto fundtransferdto) {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();	
		Account accountNumber = fundtransferdto.getFromAccount();
		Query query = entityManger.createQuery("SELECT a FROM Account a WHERE a.accountNumber LIKE :fa");
		query.setParameter("fa", accountNumber);
		List<FundTransferDto> list = (List<FundTransferDto>)query.getResultList();
		return list;
	}

	@Override
	public void deleteAccount(long accountNumber) {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();	
		Query query = entityManger.createQuery("delete from Account a where a.accountNumber LIKE :an");
		query.setParameter("an", accountNumber);
		query.executeUpdate();
		transaction.commit();
		entityManger.close();	
	}

	@Override
	public List<Account> getAccountDetails(long accountNumber, Account account) {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();	
		Query query = entityManger.createQuery("SELECT a FROM Account a WHERE a.accountNumber LIKE :ac");
		query.setParameter("ac", accountNumber);
		List list = (List<Account>)query.getResultList();
		return list;
	}

	@Override
	public void updateAccount(double accountBalance,double minimumBalance,long accountNumber) {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();	
		Query query = entityManger. createQuery("update Account a set a.accountBalance=:ab,a.minimumBalance=:mb where accountNumber=:an");
		query.setParameter("ab", accountBalance);
		query.setParameter("mb", minimumBalance);
		query.setParameter("an",accountNumber);
		query.executeUpdate();
		transaction.commit();
		entityManger.close();
		
	}
	
	
		
		
		
	}


