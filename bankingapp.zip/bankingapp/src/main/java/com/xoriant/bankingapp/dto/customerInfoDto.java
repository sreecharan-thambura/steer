package com.xoriant.bankingapp.dto;

import java.util.List;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.xoriant.bankingapp.enums.Gender;
import com.xoriant.bankingapp.model.Address;
import com.xoriant.bankingapp.model.User;


public class customerInfoDto {

	protected String personName;
	protected String emailId;
	protected long mobileNumber;
	protected List<String> genders;
	protected String gender;
	protected User user;
	protected Address address;
	

	
	public List<String> getGenders() {
		return genders;
	}

	public void setGenders(List<String> genders) {
		this.genders = genders;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}


	public void setGender(List<String> genders) {
		this.genders = genders;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "customerInfoDto [personName=" + personName + ", emailId=" + emailId + ", mobileNumber=" + mobileNumber
				+ ", gender=" + gender + ", user=" + user + ", address=" + address + "]";
	}
	
	public static void main(String[] args) {
		
		System.out.println(new customerInfoDto().genders);
	}
	

}
