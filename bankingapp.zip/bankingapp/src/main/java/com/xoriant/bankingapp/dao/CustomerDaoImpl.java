package com.xoriant.bankingapp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.xoriant.bankingapp.model.Account;
import com.xoriant.bankingapp.model.Manager;

@Repository
public class CustomerDaoImpl implements CustomerDao {
	@Autowired
	private EntityManagerFactory entityManagerFactory;

	@Override
	public Account balanceEnquiry() {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();
		/*
		 * Query qry =
		 * entityManger.createQuery("select AccountNumber,accountBalance from Account"
		 * ,Account.class); Account accountResult = (Account) qry.getSingleResult();
		 * System.out.println(accountResult); transaction.commit();
		 * entityManger.close(); return accountResult;
		 */
		
		Query q = entityManger.createQuery("SELECT accountNumber FROM Account a GROUP BY a.accountBalance");
		@SuppressWarnings("unchecked")
		List<Object[]> results = q.getResultList();
		
		for (Object[] r :  results) {
			System.out.println(r[0] + " wrote " +  r[1] + " books.");
		}
		return (Account) results;
	}

	@Override
	public List<Account> getBalanceByAccountNumber(long accountNumber) {
		EntityManager entityManger = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManger.getTransaction();
		transaction.begin();	
		Query query = entityManger.createQuery("SELECT a FROM Account a WHERE a.accountNumber LIKE :ac");
		query.setParameter("ac", accountNumber);
		List list = (List<Account>)query.getResultList();
		System.out.println(list);
		return list;
	}

}
