package com.xoriant.bankingapp.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

import com.xoriant.bankingapp.enums.AccountStatus;
import com.xoriant.bankingapp.enums.AccountType;

@Entity
public class SavingAccount extends Account {
	private double rateOfInterest;
	private double dailyLimit;
	public SavingAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SavingAccount(long accountNumber, double accountBalance, double minimumBalance, Date dateOfOpening,
			Date dataOfClosure, String description, AccountStatus accountStatus, AccountType accountType,
			List<Transaction> transactions, Customer customer) {
		super(accountNumber, accountBalance, minimumBalance, dateOfOpening, dataOfClosure, description, accountStatus,
				accountType, transactions, customer);
		// TODO Auto-generated constructor stub
	}
	public SavingAccount(long accountNumber, double accountBalance, double minimumBalance, Date dateOfOpening,
			Date dataOfClosure, String description, AccountStatus accountStatus, AccountType accountType,
			List<Transaction> transactions, Customer customer, double rateOfInterest, double dailyLimit) {
		super(accountNumber, accountBalance, minimumBalance, dateOfOpening, dataOfClosure, description, accountStatus,
				accountType, transactions, customer);
		this.rateOfInterest = rateOfInterest;
		this.dailyLimit = dailyLimit;
	}
	public double getRateOfInterest() {
		return rateOfInterest;
	}
	public void setRateOfInterest(double rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	public double getDailyLimit() {
		return dailyLimit;
	}
	public void setDailyLimit(double dailyLimit) {
		this.dailyLimit = dailyLimit;
	}
	@Override
	public String toString() {
		return "SavingAccount [rateOfInterest=" + rateOfInterest + ", dailyLimit=" + dailyLimit + "]";
	}
	
	
}
