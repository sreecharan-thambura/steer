package com.xoriant.bankingapp.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.xoriant.bankingapp.enums.Gender;
import com.xoriant.bankingapp.model.Address;
import com.xoriant.bankingapp.model.User;

public class NewCustomerDto {
	
	private String personName;
	private String emailId;
	private long mobileNumber;
	private List<String> genders;
    private User user;
	private Address address;
	
	public NewCustomerDto() {
		genders=Gender.getGenderValues();
	}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public List<String> getGenders() {
		return genders;
	}
	public void setGenders(List<String> genders) {
		this.genders = genders;
	}

	

}
