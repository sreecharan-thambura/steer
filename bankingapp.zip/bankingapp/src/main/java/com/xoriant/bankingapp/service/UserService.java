package com.xoriant.bankingapp.service;

import java.util.List;

import com.xoriant.bankingapp.model.User;

public interface UserService {
	
	void insertUser(User user);
	//User authenticateUser(String userName, String password);
	User authenticateUser(User user);
	void changepassword(String userName, String password);
	List<User> getUsers(User user);

	

}
