package com.xoriant.bankingapp.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SqlResultSetMapping;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.xoriant.bankingapp.dto.NewCustomerDto;

@Entity
@JsonIgnoreProperties(value = "manager")

public class Customer extends PersonalInfo {
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "customer")
	private List<Account> accounts;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "managerId")
	private Manager manager;

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(List<Account> accounts, Manager manager) {
		super();
		this.accounts = accounts;
		this.manager = manager;
	}

	public List<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}

	public Manager getManager() {
		return manager;
	}

	public void setManager(Manager manager) {
		this.manager = manager;
	}

	@Override
	public String toString() {
		return "Customer [personId=" + personId + ", personName=" + personName + ", emailId=" + emailId
				+ ", mobileNumber=" + mobileNumber + ", gender=" + gender + ", user=" + user + ", address=" + address
				+ "]";
	}

	
	
	
	
}
