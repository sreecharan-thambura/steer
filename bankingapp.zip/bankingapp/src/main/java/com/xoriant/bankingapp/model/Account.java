package com.xoriant.bankingapp.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.crypto.Data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.xoriant.bankingapp.dto.AccountDto;
import com.xoriant.bankingapp.enums.AccountStatus;
import com.xoriant.bankingapp.enums.AccountType;

@Entity
@JsonIgnoreProperties(value = "customer")

@Inheritance(strategy = InheritanceType.JOINED)
public class Account {
	@Id
	protected long accountNumber;
	protected double accountBalance;
	protected double minimumBalance;
	protected Date dateOfOpening;
	protected Date dataOfClosure;
	protected String description;
	
	
	/* private AccountDto accountdto; */
	

	@Enumerated(EnumType.STRING)
	protected AccountStatus accountStatus;
	
	@Enumerated(EnumType.STRING)
	protected AccountType accountType;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "fromAccount")
	protected List<Transaction> transactions;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "customerId")
	protected Customer customer;

	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Account(long accountNumber, double accountBalance, double minimumBalance, Date dateOfOpening,
			Date dataOfClosure, String description, AccountStatus accountStatus, AccountType accountType,
			List<Transaction> transactions, Customer customer) {
		super();
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.minimumBalance = minimumBalance;
		this.dateOfOpening = dateOfOpening;
		this.dataOfClosure = dataOfClosure;
		this.description = description;
		this.accountStatus = accountStatus;
		this.accountType = accountType;
		this.transactions = transactions;
		this.customer = customer;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public double getMinimumBalance() {
		return minimumBalance;
	}

	public void setMinimumBalance(double minimumBalance) {
		this.minimumBalance = minimumBalance;
	}

	public Date getDateOfOpening() {
		return dateOfOpening;
	}

	public void setDateOfOpening(Date dateOfOpening) {
		this.dateOfOpening = dateOfOpening;
	}

	public Date getDataOfClosure() {
		return dataOfClosure;
	}

	public void setDataOfClosure(Date dataOfClosure) {
		this.dataOfClosure = dataOfClosure;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public AccountStatus getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(AccountStatus accountStatus) {
		this.accountStatus = accountStatus;
	}

	public AccountType getAccountType() {
		return accountType;
	}

	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

	public List<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", minimumBalance="
				+ minimumBalance + ", dateOfOpening=" + dateOfOpening + ", dataOfClosure=" + dataOfClosure
				+ ", description=" + description + ", accountStatus=" + accountStatus + ", accountType=" + accountType
				+ ", transactions=" + transactions + ", customer=" + customer + "]";
	}
	
	
	
	
}
