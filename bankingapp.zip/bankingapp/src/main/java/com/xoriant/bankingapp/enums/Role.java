package com.xoriant.bankingapp.enums;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public enum Role {
	
	MANAGER, CUSTOMER;
	

		
		public static List<String> getRoleValues() {
			
			return Stream.of(Role.values())
	                .map(Role::name)
	                .collect(Collectors.toList());
		}
		
		public static void main(String[] args) {
			
			System.out.println(getRoleValues());
		}
		
	}
	
	


