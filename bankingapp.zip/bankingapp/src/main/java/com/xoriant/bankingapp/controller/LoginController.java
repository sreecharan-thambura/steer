package com.xoriant.bankingapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.xoriant.bankingapp.enums.Role;
import com.xoriant.bankingapp.model.User;
import com.xoriant.bankingapp.service.UserService;

@Controller
public class LoginController {

	@Autowired
	UserService userservice;

	@RequestMapping("/")
	public String home() {
		return "Home";
	}

	@RequestMapping("/login")
	public String login() {
		return "login";
	}

	@PostMapping("/Login")
	public String addUser(@RequestParam String userName, @RequestParam String password, User user, Model model) {
		List<User> list = userservice.getUsers(user);
		for (User u : list) {
			String name = u.getUserName();
			String pass = u.getPassword();
			Role role = u.getRole();
			if (name.equals(userName) && pass.equals(password)&& role.equals(Role.MANAGER)) {
				return "Manager";
			}
				else if (name.equals(userName) && pass.equals(password)&& role.equals(Role.CUSTOMER)) {
					return "Customer";

				}
			}
			

		

		model.addAttribute("message", "Invalid Username or Password!!!");
		return "login";

	}

	/*
	 * @PostMapping("/addUser") public String addUser(@ModelAttribute User userObj)
	 * {
	 * 
	 * userService.insertUser(userObj); if(userObj.getRole().equals(Role.CUSTOMER))
	 * return "login"; }
	 */

	@RequestMapping("/changePassword")
	public String changepassword() {
		return "ChangePassword";
	}

	@PostMapping("/changePassword")
	public String changepassword(@RequestParam String userName, @RequestParam String password) {
		userservice.changepassword(userName, password);
		return "login";
	}

}
