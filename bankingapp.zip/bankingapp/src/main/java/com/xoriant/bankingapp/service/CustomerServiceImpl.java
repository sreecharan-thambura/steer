package com.xoriant.bankingapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xoriant.bankingapp.dao.CustomerDao;
import com.xoriant.bankingapp.model.Account;

@Service
public class CustomerServiceImpl implements CustomerService{
@Autowired
CustomerDao customerDao;
	@Override
	public Account balanceEnquiry()
	{
		return customerDao.balanceEnquiry();
	}
	@Override
	public List<Account> getBalanceByAccountNumber(long accountNumber) {
		return customerDao.getBalanceByAccountNumber(accountNumber);
	}
}
